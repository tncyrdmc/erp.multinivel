		<!-- MAIN CONTENT -->
			<div id="content" >
				<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
				
				<!-- PAGE HEADER -->
				<i class="fa-fw fa fa-pencil-square-o"></i> 
					<a href="/bo/dashboard">Dashboard</a>
				<span>>
					<a href="/bo/comisiones">Comisiones</a>
				</span>
				<span>>
					Bono uno
				</span>
			</h1>
		</div>
	</div>
				<div>
					<div class="row">
						<div class="col-sm-12 col-md-12 col-lg-12">
							<div class="row">
								<div class="col-sm-12 col-md-12 col-lg-12">
									<!--Inica la secciion de la perfil y red-->
									<div class="well">
										<div class="row">
											<div class="col-sm-3">
											</div>
											<div class="col-sm-3 link">
												<a href="/bo/comisiones/parcial_uno">
													<div class="minh well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_2_color?>">
														<i class="fa fa-star-half fa-4x"></i>
														<h1>Parcial</h1>
													</div>
												</a>
											</div>
											<div class="col-sm-3 link">
												<a href="/bo/comisiones/final_uno">
													<div class="minh well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_1_color?>;">
														<i class="fa fa fa-star fa-4x"></i>
														<h1>Final</h1>
													</div>
												</a>
											</div>
										</div>
									</div>
									<!--Termina la secciion de perfil y red-->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">         
			        <!-- a blank row to get started -->
			        <div class="col-sm-12">
			            <br />
			            <br />
			        </div>
		        </div>
			</div>
			<!-- END MAIN CONTENT -->
<style>
.minh
{
	padding: 50px;
}
.link a:hover
{
	text-decoration: none !important;
}
</style>