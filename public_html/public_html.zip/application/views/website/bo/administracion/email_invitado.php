<div class="container">
  <div class="row">
  <div class="col-xs-6 col-md-6 col-sm-6 col-lg-6">
  <form id="login-form" method="POST" action="/bo/administracion/enviar_invitacion" class="smart-form client-form">
								<header>
									Invitacion a mi web personal
								</header>
								<fieldset>
							
									
										<section>
											<label class="label">Cuenta</label>
											<label class="input"> <i class="icon-append fa fa-mail-reply"></i>
												<input required type="email" placeholder="Cuenta de Email a invitar" name="email_invitado">
												<b class="tooltip tooltip-top-right"><i class="fa  txt-color-teal"></i> Ingrese un cuanta de correo valida</b></label>
										</section>

									
								</fieldset>
								<footer>
									<button id="enviar" type="submit" class="btn btn-primary">
										Enviar Invitacion
									</button>
								</footer>
							</form>
							</div>
  </div>
</div>