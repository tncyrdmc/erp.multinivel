<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<form action="/bo/tipo_red/guardar_red" method="POST" role="form">
		<legend>Nueva Red</legend>
	
		<div class="form-group">
			<label for="">Nombre</label>
			<input type="text" class="form-control" name="nombre" >

			<label for="">Descripcion</label>
			<input type="text" class="form-control" name="descripcion" >
		</div>
		<button type="submit" class="btn btn-primary">Crear</button>
	</form>
</div>