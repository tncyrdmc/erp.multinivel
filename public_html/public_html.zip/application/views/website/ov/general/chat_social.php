<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
					<a class="backHome" href="/ov"><i class="fa fa-home"></i> Menu</a> 
				<span>>
					<a href="/ov/cgeneral/chat">Menu chat</a>
				</span>
				<span>>
					chat
					<a href="/cometchat/admin/index.php" >HOme</a>	
				</span>
			</h1>
		</div>
	</div>
	
<link type="text/css" href="/cometchat/cometchatcss.php" rel="stylesheet" charset="utf-8">
<script type="text/javascript" src="/cometchat/cometchatjs.php" charset="utf-8"></script>
<script>

</script>