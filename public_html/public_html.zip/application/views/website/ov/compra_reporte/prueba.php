<form method="post" action="/ov/compras/registrarVentaWebPersonal">
	estado<input name="state_pol">	
	referencia<input name="reference_sale">
	id_use<input name="extra2">
	id_mer<input name="extra1">
	firma<input name="sign">
	metodo<input name="payment_method_id">
	respues<input name="response_code_pol">
	fecha<input name="transaction_date">
	moneda<input name="currency">
	email<input name="email_buyer">
	direccion<input name="shipping_address">
	telefono<input name="phone">
	inde<input name="transaction_id">
	medio<input name="payment_method_name">
	coisto<input name="value">
	
	<input type="submit">
</form>